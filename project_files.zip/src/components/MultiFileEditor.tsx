import React from 'react';
import Editor, { type Monaco } from '@monaco-editor/react';
import { FileCode2, Loader2 } from 'lucide-react';
import EditorTabs from './EditorTabs';
import { FileWorkspace } from '../hooks/useFileWorkspace';
import { ProjectType, monacoLanguageFor } from '../types/files';
import { monacoThemeFor, defineGbCoderTheme } from '../utils/monacoTheme';
import { useTheme } from '../hooks/useTheme';
import { BundleError, formatBundleError } from '../services/bundlerService';
import { ValidationSummary } from '../services/validationService';
import { ataService } from '../services/ata/ataService';

interface MultiFileEditorProps {
  projectType: ProjectType;
  workspace: FileWorkspace;
  fontFamily: string;
  fontSize: number;
  buildStatus: 'idle' | 'building' | 'error' | 'ready';
  buildErrors: BundleError[];
  /** Wired to the AI selection toolbar, same as the plain-mode panels. */
  onSelectionChange?: (editor: unknown, path: string) => void;
  /** Registers the mounted editor for click-to-jump navigation. */
  onEditorReady?: (key: string, editor: unknown, monaco: unknown) => void;
  validationSummary?: ValidationSummary;
}

const STATUS_LABEL: Record<MultiFileEditorProps['buildStatus'], string> = {
  idle: '',
  building: 'Building…',
  error: 'Build failed',
  ready: 'Ready',
};

/**
 * The editor surface for multi-file React/Vue projects: a tab strip plus a
 * single Monaco instance.
 *
 * `path` is passed to Monaco, which keeps one model per file. That preserves
 * per-file undo history, cursor position and scroll offset when switching tabs —
 * a plain value swap would reset all three.
 */
const MultiFileEditor: React.FC<MultiFileEditorProps> = ({
  projectType,
  workspace,
  fontFamily,
  fontSize,
  buildStatus,
  buildErrors,
  onSelectionChange,
  onEditorReady,
  validationSummary,
}) => {
  const { activeFile } = workspace;
  const { isDark } = useTheme();

  const handleWillMount = (monaco: Monaco) => defineGbCoderTheme(monaco);

  const handleMount = (editor: unknown, monaco: unknown) => {
    /*
     * The instance is now retained (via onEditorReady) instead of being
     * dropped. Without it, nothing could reveal a line in multi-file mode, so
     * Problems rows and stack frames had nowhere to navigate to.
     */
    if (activeFile) onEditorReady?.(activeFile.path, editor, monaco);

    if (monaco) {
      void ataService.init(monaco as Monaco).then(() => {
        if (workspace.files) {
          ataService.acquireTypesForProject(workspace.files);
        }
      });
    }

    if (!onSelectionChange || !activeFile) return;
    const instance = editor as { onDidChangeCursorSelection: (cb: () => void) => void };
    instance.onDidChangeCursorSelection(() => onSelectionChange(editor, activeFile.path));
  };

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden rounded-lg border border-stroke-dark bg-product">
      <EditorTabs
        openPaths={workspace.openPaths}
        activePath={workspace.activePath}
        dirtyPaths={workspace.dirtyPaths}
        onSelect={workspace.setActivePath}
        onClose={workspace.closeFile}
        validationSummary={validationSummary}
      />

      <div className="min-h-0 flex-1">
        {activeFile ? (
          <div className="relative h-full w-full">
            {!activeFile.content.trim() && (
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center opacity-60 z-10 text-content-on-dark-soft">
                <FileCode2 className="w-8 h-8 mb-2" />
                <span className="text-sm font-medium">Type {activeFile.language} here</span>
              </div>
            )}
            <Editor
              /* Per-file model: keyed by path so each file keeps its own state. */
              path={activeFile.path}
              language={monacoLanguageFor(activeFile.language)}
              value={activeFile.content}
              onChange={(value) => {
                const text = value ?? '';
                workspace.updateFileContent(activeFile.path, text);
                ataService.acquireTypes(text);
              }}
              beforeMount={handleWillMount}
              onMount={handleMount}
              theme={monacoThemeFor(isDark)}
              loading={
                <div className="flex h-full items-center justify-center gap-2 text-sm text-content-on-dark-soft">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading editor…
                </div>
              }
              options={{
                minimap: { enabled: false },
                fontSize,
                fontFamily,
                lineNumbers: 'on',
                roundedSelection: false,
                scrollBeyondLastLine: false,
                automaticLayout: true,
                tabSize: 2,
                insertSpaces: true,
              }}
            />
          </div>
        ) : (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center text-content-on-dark">
            <div className="rounded-lg border border-stroke-dark bg-product-elevated p-3">
              <FileCode2 className="h-6 w-6 text-content-on-dark-soft" />
            </div>
            <p className="text-sm font-medium text-content-on-dark">No file open</p>
            <p className="text-xs text-content-on-dark-soft">
              Pick a file from the explorer to start editing.
            </p>
          </div>
        )}
      </div>

      {/* Build status strip. Full error text still goes to the Console tab. */}
      {projectType !== 'plain' && buildStatus !== 'idle' && (
        <div className="flex items-center gap-2 border-t border-stroke-dark bg-product-soft px-3 py-1.5 text-[11px] text-content-on-dark">
          {buildStatus === 'building' && <Loader2 className="h-3 w-3 animate-spin text-accent" />}
          <span
            className={
              buildStatus === 'error'
                ? 'text-red-300'
                : buildStatus === 'building'
                  ? 'text-content-on-dark-soft'
                  : 'text-emerald-300'
            }
          >
            {STATUS_LABEL[buildStatus]}
          </span>
          {buildStatus === 'error' && buildErrors[0] && (
            <span className="truncate text-content-on-dark-soft" title={buildErrors.map(formatBundleError).join('\n')}>
              {formatBundleError(buildErrors[0])}
            </span>
          )}
          {buildStatus === 'error' && buildErrors.length > 1 && (
            <span className="shrink-0 text-content-on-dark-soft">+{buildErrors.length - 1} more</span>
          )}
        </div>
      )}
    </div>
  );
};

export default React.memo(MultiFileEditor);
