import React, { useState } from 'react';
import { X, Minus, Plus, History, Trash2, ChevronRight, Check, Code2, AlertCircle, Menu } from 'lucide-react';
import { SelectionOperationResult } from '../services/selectionOperationsService';
import { EditorLanguage, HistoryItem } from '../types';

interface SelectionSidebarProps {
    isOpen: boolean;
    isLoading: boolean;
    result: SelectionOperationResult | null;
    language: EditorLanguage | null;
    error: string | null;
    onClose: () => void;
    onApplyChanges?: (code: string) => void;
    history: HistoryItem[];
    onClearHistory: () => void;
    onSelectHistory: (item: HistoryItem) => void;
    isHistoryOpen: boolean;
    onHistoryToggle: (isOpen: boolean) => void;
}

// Custom Lade Stack Loader Component
const LadeStackLoader: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center py-12">
            <div className="w-10 h-10 border-2 border-stroke-dark border-t-accent rounded-full animate-spin mb-4" />
            <div className="text-center">
                <h3 className="text-[15px] font-semibold text-content-on-dark">
                    Lade Stack AI
                </h3>
                <p className="text-[12.5px] text-content-on-dark-soft mt-1">
                    Analyzing selected code...
                </p>
            </div>
            <div className="w-44 h-1 bg-product-elevated border border-stroke-dark rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-accent rounded-full animate-progress" />
            </div>
        </div>
    );
};

const SelectionSidebar: React.FC<SelectionSidebarProps> = ({
    isOpen,
    isLoading,
    result,
    error,
    onClose,
    onApplyChanges,
    history,
    onClearHistory,
    onSelectHistory,
    isHistoryOpen,
    onHistoryToggle,
}) => {
    const [isMinimized, setIsMinimized] = useState(false);
    const [showDiff, setShowDiff] = useState(false);

    if (!isOpen) return null;

    const getOperationIcon = () => {
        switch (result?.operation) {
            case 'explain': return '💡';
            case 'debug': return '🐛';
            case 'optimize': return '⚡';
            case 'improveUI': return '🎨';
            default: return '🤖';
        }
    };

    const getOperationTitle = () => {
        switch (result?.operation) {
            case 'explain': return 'Code Explanation';
            case 'debug': return 'Debug Analysis';
            case 'optimize': return 'Optimization Suggestions';
            case 'improveUI': return 'UI Improvements';
            default: return 'AI Assistant';
        }
    };

    const formatTime = (timestamp: number) => {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now.getTime() - date.getTime();

        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return date.toLocaleDateString();
    };

    return (
        <>
            {/* Minimized state - floating pill */}
            {isMinimized && (
                <div
                    className="fixed right-4 top-1/2 -translate-y-1/2 z-50 bg-product border border-stroke-dark text-content-on-dark px-3.5 py-2.5 rounded-md cursor-pointer hover:bg-product-elevated transition-colors flex items-center gap-2"
                    onClick={() => setIsMinimized(false)}
                >
                    {isLoading ? (
                        <>
                            <div className="w-3.5 h-3.5 border-2 border-stroke-dark border-t-accent rounded-full animate-spin" />
                            <span className="text-[12.5px] font-medium">Analyzing...</span>
                        </>
                    ) : (
                        <>
                            <span>{getOperationIcon()}</span>
                            <span className="text-[12.5px] font-medium">View Result</span>
                        </>
                    )}
                    <Plus className="w-3.5 h-3.5 ml-1 text-content-on-dark-soft" />
                </div>
            )}

            {/* Full sidebar */}
            {!isMinimized && (
                <div className="fixed right-0 top-0 h-full w-full md:w-[420px] bg-product border-l border-stroke-dark z-50 flex flex-col animate-slideIn">
                    {/* Header */}
                    <div className="bg-product px-4 py-3 border-b border-stroke-dark flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                            <button
                                onClick={() => onHistoryToggle(!isHistoryOpen)}
                                className={`p-1.5 rounded-md transition-colors ${isHistoryOpen ? 'bg-product-elevated text-content-on-dark' : 'text-content-on-dark-soft hover:text-content-on-dark hover:bg-product-elevated'}`}
                                title="View History"
                            >
                                <Menu className="w-4 h-4" />
                            </button>

                            {isLoading ? (
                                <div className="flex items-center gap-2">
                                    <div className="w-4 h-4 border-2 border-stroke-dark border-t-accent rounded-full animate-spin" />
                                    <span className="text-[13px] font-medium text-content-on-dark-soft">Processing...</span>
                                </div>
                            ) : (
                                <div className="flex items-center gap-2">
                                    <span>{getOperationIcon()}</span>
                                    <span className="text-[14px] font-medium text-content-on-dark">{getOperationTitle()}</span>
                                </div>
                            )}
                        </div>

                        <div className="flex items-center gap-1">
                            <button
                                onClick={() => setIsMinimized(true)}
                                className="p-2 hover:bg-product-active rounded-lg transition-colors text-content-on-dark-soft hover:text-content-on-dark"
                                title="Minimize"
                            >
                                <Minus className="w-4 h-4" />
                            </button>
                            <button
                                onClick={onClose}
                                className="p-2 hover:bg-product-active rounded-lg transition-colors text-content-on-dark-soft hover:text-content-on-dark"
                                title="Close"
                            >
                                <X className="w-4 h-4" />
                            </button>
                        </div>
                    </div>

                    {/* History Panel (slides in from left) */}
                    {isHistoryOpen && (
                        <div className="absolute left-0 top-0 h-full w-64 bg-product-soft border-r border-stroke-dark z-10 shadow-2xl animate-slideIn">
                            <div className="p-4 border-b border-stroke-dark flex items-center justify-between">
                                <h3 className="font-semibold text-content-on-dark flex items-center gap-2">
                                    <History className="w-4 h-4" />
                                    Recent History
                                </h3>
                                <div className="flex items-center gap-1">
                                    {history.length > 0 && (
                                        <button
                                            onClick={onClearHistory}
                                            className="p-1.5 hover:bg-danger-subtle rounded text-red-300 hover:text-red-300 transition-colors"
                                            title="Clear History"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    )}
                                    <button
                                        onClick={() => onHistoryToggle(false)}
                                        className="p-1.5 hover:bg-product-active rounded text-content-on-dark-soft hover:text-content-on-dark transition-colors"
                                    >
                                        <X className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>

                            <div className="overflow-y-auto h-[calc(100%-60px)]">
                                {history.length === 0 ? (
                                    <p className="text-content-on-dark-soft text-center py-8 text-sm">No history yet</p>
                                ) : (
                                    <div className="divide-y divide-stroke-dark">
                                        {history.map((item) => (
                                            <button
                                                key={item.id}
                                                onClick={() => {
                                                    onSelectHistory(item);
                                                    onHistoryToggle(false);
                                                }}
                                                className="w-full p-3 text-left hover:bg-product-elevated transition-colors"
                                            >
                                                <div className="flex items-center justify-between mb-1">
                                                    <span className="text-xs font-medium text-accent uppercase">
                                                        {item.operation}
                                                    </span>
                                                    <span className="text-xs text-content-on-dark-soft">
                                                        {formatTime(item.timestamp)}
                                                    </span>
                                                </div>
                                                <p className="text-sm text-content-on-dark truncate">{item.codePreview}</p>
                                                <span className="text-xs text-content-on-dark-soft uppercase">{item.language}</span>
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Content */}
                    <div className="flex-1 overflow-y-auto">
                        {/* Loading State */}
                        {isLoading && <LadeStackLoader />}

                        {/* Error State */}
                        {error && !isLoading && (
                            <div className="p-6">
                                <div className="bg-danger-subtle border border-red-700 rounded-lg p-4 flex items-start gap-3">
                                    <AlertCircle className="w-5 h-5 text-red-300 flex-shrink-0 mt-0.5" />
                                    <div>
                                        <h4 className="font-semibold text-red-300">Operation Failed</h4>
                                        <p className="text-sm text-red-300 mt-1">{error}</p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Result State */}
                        {result && !isLoading && (
                            <div className="p-4 space-y-4">
                                {/* Explanation */}
                                <div className="bg-product-soft border border-stroke-dark rounded-lg p-4">
                                    <h3 className="text-sm font-semibold text-content-on-dark mb-2 flex items-center gap-2">
                                        <Code2 className="w-4 h-4 text-accent" />
                                        Analysis
                                    </h3>
                                    <p className="text-sm text-content-on-dark whitespace-pre-wrap leading-relaxed">
                                        {result.explanation}
                                    </p>
                                </div>

                                {/* Confidence */}
                                {result.confidence !== undefined && (
                                    <div className="bg-product-soft border border-stroke-dark rounded-lg p-4">
                                        <h3 className="text-sm font-semibold text-content-on-dark mb-2">Confidence</h3>
                                        <div className="flex items-center gap-3">
                                            <div className="flex-1 bg-product-active rounded-full h-2 overflow-hidden">
                                                <div
                                                    className="h-full bg-gradient-to-r from-accent to-accent-hover transition-all duration-500"
                                                    style={{ width: `${result.confidence}%` }}
                                                />
                                            </div>
                                            <span className="text-sm font-medium text-content-on-dark">{result.confidence}%</span>
                                        </div>
                                    </div>
                                )}

                                {/* Issues */}
                                {result.issues && result.issues.length > 0 && (
                                    <div className="bg-product-soft border border-stroke-dark rounded-lg p-4">
                                        <h3 className="text-sm font-semibold text-content-on-dark mb-3 flex items-center gap-2">
                                            <AlertCircle className="w-4 h-4 text-red-300" />
                                            Issues ({result.issues.length})
                                        </h3>
                                        <div className="space-y-2">
                                            {result.issues.map((issue, i) => (
                                                <div key={i} className={`p-3 rounded border ${issue.severity === 'high' ? 'border-red-700 bg-danger-subtle' :
                                                    issue.severity === 'medium' ? 'border-yellow-700 bg-yellow-900/20' :
                                                        'border-accent/50 bg-accent-subtle'
                                                    }`}>
                                                    <div className="flex items-center justify-between mb-1">
                                                        <span className="text-xs font-semibold uppercase">{issue.type}</span>
                                                        <span className={`text-xs px-2 py-0.5 rounded ${issue.severity === 'high' ? 'bg-red-800 text-red-200' :
                                                            issue.severity === 'medium' ? 'bg-yellow-800 text-yellow-200' :
                                                                'bg-accent-subtle text-accent'
                                                            }`}>{issue.severity}</span>
                                                    </div>
                                                    <p className="text-sm text-content-on-dark">{issue.description}</p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/* Improvements */}
                                {result.improvements && result.improvements.length > 0 && (
                                    <div className="bg-product-soft border border-stroke-dark rounded-lg p-4">
                                        <h3 className="text-sm font-semibold text-content-on-dark mb-3 flex items-center gap-2">
                                            <Check className="w-4 h-4 text-success" />
                                            Improvements
                                        </h3>
                                        <ul className="space-y-2">
                                            {result.improvements.map((imp, i) => (
                                                <li key={i} className="flex items-start gap-2 text-sm text-content-on-dark">
                                                    <span className="text-success mt-0.5">✓</span>
                                                    <span>{imp}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                )}

                                {/* Suggested Code */}
                                {result.hasCodeChanges && result.suggestedCode && (
                                    <div className="bg-product-soft border border-stroke-dark rounded-lg overflow-hidden">
                                        <button
                                            onClick={() => setShowDiff(!showDiff)}
                                            className="w-full px-4 py-3 flex items-center justify-between hover:bg-product-active transition-colors"
                                        >
                                            <h3 className="text-sm font-semibold text-content-on-dark flex items-center gap-2">
                                                <Code2 className="w-4 h-4" />
                                                Suggested Code
                                            </h3>
                                            <ChevronRight className={`w-4 h-4 text-content-on-dark-soft transition-transform ${showDiff ? 'rotate-90' : ''}`} />
                                        </button>
                                        {showDiff && (
                                            <div className="border-t border-stroke-dark p-3 bg-product">
                                                <pre className="text-xs text-content-on-dark overflow-x-auto whitespace-pre-wrap">
                                                    <code>{result.suggestedCode}</code>
                                                </pre>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                    {/* Footer - Apply Button */}
                    {result?.hasCodeChanges && result.suggestedCode && onApplyChanges && !isLoading && (
                        <div className="p-4 border-t border-stroke-dark bg-product">
                            <button
                                onClick={() => onApplyChanges(result.suggestedCode!)}
                                className="w-full px-4 py-2.5 bg-accent hover:bg-accent-hover text-content-on-dark font-medium rounded-md transition-colors flex items-center justify-center gap-2 text-[13px]"
                            >
                                <Check className="w-4 h-4" />
                                Review Changes
                            </button>
                        </div>
                    )}
                </div>
            )}

            {/* Styles for animations */}
            <style>{`
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        .animate-slideIn {
          animation: slideIn 0.3s ease-out;
        }
        @keyframes progress {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
        .animate-progress {
          animation: progress 1.5s ease-in-out infinite;
        }
      `}</style>
        </>
    );
};

export default SelectionSidebar;
